using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class GameEvent 
{
    public const string WEATHER_UPDATED = "WEATHER_UPDATED";
}

namespace Unity.VisualScripting
{
    public enum TypesMatching
    {
        ConvertibleToAny,
        AssignableToAll,
        Any
    }
}

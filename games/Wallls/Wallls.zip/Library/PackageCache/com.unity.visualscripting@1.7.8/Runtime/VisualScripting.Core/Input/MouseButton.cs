namespace Unity.VisualScripting
{
    public enum MouseButton
    {
        Left = 0,
        Right = 1,
        Middle = 2
    }
}

namespace Unity.VisualScripting
{
    public enum TypeNameDetail
    {
        Name,

        NameAndAssembly,

        Full
    }
}

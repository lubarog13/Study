namespace Unity.VisualScripting
{
    public interface IPrewarmable
    {
        void Prewarm();
    }
}

namespace Unity.Services.Core.Device
{
    interface IUserIdentifierProvider
    {
        string UserId { get; set; }
    }
}

namespace Unity.Services.Core.Editor
{
    interface IProjectStateRequest
    {
        ProjectState GetProjectState();
    }
}

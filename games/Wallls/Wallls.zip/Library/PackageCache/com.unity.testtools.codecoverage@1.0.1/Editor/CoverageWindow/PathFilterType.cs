﻿namespace UnityEditor.TestTools.CodeCoverage
{
    internal enum PathFilterType
    {
        Include = 0,
        Exclude = 1
    }
}
